#!/bin/bash

# Make sure script is run as root
if [ "$EUID" -ne 0 ]; then
  echo "Please run as root (use sudo)"
  exit 1
fi

echo "=== Uninstalling MXAG7 AI Agent ==="

# Remove symlink
echo "Removing command symlink..."
rm -f /usr/local/bin/mxag7

# Remove installation directory
echo "Removing application files..."
rm -rf /opt/mxag7

# Remove configuration files
echo "Removing configuration files..."
rm -rf /root/.config/mxag7

echo "=== Uninstallation Complete ==="