#!/bin/bash

# Make sure script is run as root
if [ "$EUID" -ne 0 ]; then
  echo "Please run as root (use sudo)"
  exit 1
fi

echo "=== Installing MXAG7 AI Agent ==="

# Update package lists
echo "Updating package lists..."
apt-get update

# Install required packages
echo "Installing required packages..."
apt-get install -y python3 python3-pip python3-venv

# Create virtual environment
echo "Setting up Python virtual environment..."
mkdir -p /opt/mxag7
python3 -m venv /opt/mxag7/venv

# Install required Python packages
echo "Installing Python dependencies..."
/opt/mxag7/venv/bin/pip install openai requests

# Copy files to installation directory
echo "Installing application files..."
cp mxag7.py /opt/mxag7/
chmod +x /opt/mxag7/mxag7.py

# Create symlink to allow running from anywhere
echo "Creating command symlink..."
ln -sf /opt/mxag7/mxag7.py /usr/local/bin/mxag7

# Create configuration directory
mkdir -p /root/.config/mxag7

echo "=== Installation Complete ==="
echo "Run 'sudo mxag7 setup' to configure your AI API key."