#!/usr/bin/env python3

import os
import sys
import json
import subprocess
from pathlib import Path
import ollama  # Use Ollama for local AI models

# Configuration file path
CONFIG_FILE = Path.home() / ".config" / "mxag7" / "config.json"

def load_config():
    """Load configuration from config file."""
    try:
        with open(CONFIG_FILE, 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        print("Configuration file not found. Please run 'sudo mxag7 setup' first.")
        sys.exit(1)
    except json.JSONDecodeError:
        print("Invalid configuration file. Please run 'sudo mxag7 setup' again.")
        sys.exit(1)

def setup():
    """Setup the AI agent (Ollama does not require API keys)."""
    print("=== MXAG7 AI Agent Setup ===")
    print("Ollama LLM is being used for local AI functionality. No API key is required.")
    print("Setup completed successfully!")

def get_ai_guidance(command):
    """Get AI guidance on how to execute a command."""
    try:
        prompt = f"""
        I need to execute the following command on Ubuntu Linux:
        {command}
        
        Please provide:
        1. What this command does
        2. The correct way to execute it
        3. Any potential risks or considerations
        4. Dependencies needed (if any)
        """
        
        response = ollama.run("llama2", prompt)  # Use Ollama's local model
        return response.strip()
    except Exception as e:
        return f"Error consulting AI: {e}"

def execute_command(command):
    """Execute a system command with AI guidance."""
    # First get AI guidance
    guidance = get_ai_guidance(command)
    
    print("=== AI Analysis ===")
    print(guidance)
    print("\n=== Execution ===")
    
    # Ask for confirmation
    print(f"\nDo you want to execute: {command}? (y/n)")
    confirmation = input("> ").strip().lower()
    
    if confirmation != 'y':
        print("Command execution cancelled.")
        return
    
    # Execute the command
    try:
        result = subprocess.run(command, shell=True, check=True, 
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE, 
                                text=True)
        print("\n=== Output ===")
        print(result.stdout)
        
        if result.stderr:
            print("\n=== Errors ===")
            print(result.stderr)
            
        print("\n=== Command executed successfully ===")
    except subprocess.CalledProcessError as e:
        print("\n=== Execution Failed ===")
        print(f"Return code: {e.returncode}")
        print("\n=== Output ===")
        print(e.stdout)
        print("\n=== Errors ===")
        print(e.stderr)

def main():
    """Main function to handle command line arguments."""
    if len(sys.argv) < 2:
        print("Usage: sudo mxag7 [command]")
        print("       sudo mxag7 setup - Configure the AI agent")
        return
    
    # Handle setup command
    if sys.argv[1] == 'setup':
        setup()
        return
    
    # Handle actual commands
    command = ' '.join(sys.argv[1:])
    execute_command(command)

if __name__ == "__main__":
    # Check if running as root
    if os.geteuid() != 0:
        print("This script must be run as root. Please use sudo.")
        sys.exit(1)
    
    main()