# MXAG7 - AI-Powered Command Line Assistant

MXAG7 is an AI-powered command-line tool that helps Ubuntu system administrators execute commands with AI guidance and analysis.

## Features

- Analyzes commands before execution
- Provides insights on command purpose and risks
- Identifies required dependencies
- Confirms execution before proceeding
- Simplifies complex system administration tasks

## Installation

1. Clone the repository:
   ```bash
   git clone https://github.com/your-username/mxag7.git
   cd mxag7
   ```

2. Install dependencies:
   ```bash
   sudo bash install.sh
   ```

3. Set up the AI agent (no API key required):
   ```bash
   sudo mxag7 setup
   ```

## Usage

To use MXAG7, simply prefix your commands with `sudo mxag7`:

```bash
# Example: Install Postal mail server
sudo mxag7 install postal

# Example: Update system packages
sudo mxag7 apt update && apt upgrade -y
```

## Requirements

- Ubuntu Linux (tested on Ubuntu 20.04+)
- Python 3.8 or newer
- Root access (sudo)

## License

MIT License